/* NEXFORMA Business Solutions — site script (English & Arabic) */
(function () {
  'use strict';
  var root = document.documentElement;
  var isAr = root.lang === 'ar';
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---- Animations are opt-in: content stays visible if this script is slow or fails ---- */
  root.classList.add('js');
  var animEls = document.querySelectorAll('.reveal, .zoom, .bars');
  function showAll() { animEls.forEach(function (el) { el.classList.add('in'); }); }
  if (reduce || !('IntersectionObserver' in window)) {
    showAll();
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });
    animEls.forEach(function (el) {
      // anything already on screen shows immediately
      var r = el.getBoundingClientRect();
      if (r.top < window.innerHeight) el.classList.add('in'); else io.observe(el);
    });
    // safety net: never leave sections hidden
    setTimeout(showAll, 4000);
  }

  /* ---- Mobile menu ---- */
  var menuBtn = document.querySelector('.menu-btn');
  var menu = document.getElementById('mobile-menu');
  if (menuBtn && menu) {
    menuBtn.addEventListener('click', function () {
      var open = menuBtn.getAttribute('aria-expanded') === 'true';
      menuBtn.setAttribute('aria-expanded', String(!open));
      menuBtn.setAttribute('aria-label', open ? menuBtn.dataset.open : menuBtn.dataset.close);
      menu.hidden = open;
    });
    menu.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') { menu.hidden = true; menuBtn.setAttribute('aria-expanded', 'false'); }
    });
  }

  /* ---- Word-by-word light-up ---- */
  var words = document.querySelector('.words');
  if (words && !reduce) {
    var spans = words.querySelectorAll('span');
    var ticking = false;
    var update = function () {
      var r = words.getBoundingClientRect();
      var vh = window.innerHeight;
      var p = (vh * 0.85 - r.top) / (vh * 0.5 + r.height * 0.5);
      p = Math.max(0, Math.min(1, p));
      var lit = Math.round(p * spans.length);
      spans.forEach(function (s, i) { s.classList.toggle('lit', i < lit); });
      ticking = false;
    };
    window.addEventListener('scroll', function () {
      if (!ticking) { window.requestAnimationFrame(update); ticking = true; }
    }, { passive: true });
    update();
  }

  /* ---- Tabs (industry selector, demos, plans) ---- */
  document.querySelectorAll('[role="tablist"]').forEach(function (list) {
    var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
    function select(n, focus) {
      tabs.forEach(function (t, k) {
        var on = k === n;
        t.setAttribute('aria-selected', String(on));
        t.tabIndex = on ? 0 : -1;
        var panel = document.getElementById(t.getAttribute('aria-controls'));
        if (panel) panel.hidden = !on;
      });
      if (focus) tabs[n].focus();
    }
    tabs.forEach(function (tab, idx) {
      tab.addEventListener('click', function () { select(idx); });
      tab.addEventListener('keydown', function (e) {
        var fwd = isAr ? 'ArrowLeft' : 'ArrowRight';
        var back = isAr ? 'ArrowRight' : 'ArrowLeft';
        if (e.key === fwd) { e.preventDefault(); select((idx + 1) % tabs.length, true); }
        if (e.key === back) { e.preventDefault(); select((idx - 1 + tabs.length) % tabs.length, true); }
      });
    });
  });

  /* ---- FAQ accordion ---- */
  document.querySelectorAll('.faq-item button').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var open = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!open));
      document.getElementById(btn.getAttribute('aria-controls')).hidden = open;
    });
  });

  /* ---- Money helpers (BHD has 3 decimals) ---- */
  var VAT = 0.10;
  function bhd(n) {
    return 'BHD ' + n.toLocaleString('en-US', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
  }
  function num(v) { var n = parseFloat(String(v).replace(/,/g, '')); return isNaN(n) ? 0 : n; }
  function setText(scope, sel, txt) { var el = scope.querySelector(sel); if (el) el.textContent = txt; }

  /* ---- Demo 1: site work → approved invoice ---- */
  document.querySelectorAll('[data-demo="site"]').forEach(function (d) {
    var rate = num(d.dataset.rate), contract = num(d.dataset.contract), prev = num(d.dataset.prev);
    var qty = d.querySelector('[data-qty]');
    var approveBtn = d.querySelector('[data-approve]');
    var resetBtn = d.querySelector('[data-reset]');
    var err = d.querySelector('[data-error]');
    var approved = false;

    function render() {
      var q = num(qty.value);
      var remaining = contract - prev;
      var valid = q > 0 && q <= remaining;
      err.hidden = valid || qty.value === '';
      approveBtn.disabled = !valid || approved;
      var pct = Math.min(100, ((prev + (valid ? q : 0)) / contract) * 100);
      d.querySelector('[data-bar]').style.width = pct.toFixed(1) + '%';
      setText(d, '[data-pct]', pct.toFixed(1) + '%');
      var amount = valid ? q * rate : 0;
      setText(d, '[data-line]', (valid ? q.toLocaleString('en-US') : '0') + ' × ' + bhd(rate));
      setText(d, '[data-amount]', bhd(amount));
      setText(d, '[data-vat]', bhd(amount * VAT));
      setText(d, '[data-total]', bhd(amount * (1 + VAT)));
      d.classList.toggle('is-approved', approved);
      d.querySelector('[data-state]').textContent = approved ? d.dataset.txtApproved : d.dataset.txtPending;
    }
    qty.addEventListener('input', function () { approved = false; render(); });
    approveBtn.addEventListener('click', function () { approved = true; render(); var inv = d.querySelector('.inv'); if (inv) inv.focus(); });
    resetBtn.addEventListener('click', function () { approved = false; qty.value = qty.defaultValue; render(); qty.focus(); });
    render();
  });

  /* ---- Demo 2: service request → customer handover ---- */
  document.querySelectorAll('[data-demo="service"]').forEach(function (d) {
    var steps = Array.prototype.slice.call(d.querySelectorAll('.svc-step'));
    var dots = Array.prototype.slice.call(d.querySelectorAll('.svc-dots li'));
    var next = d.querySelector('button[data-next]');
    var reset = d.querySelector('button[data-reset]');
    var labour = d.querySelector('[data-labour]');
    var parts = d.querySelector('[data-parts]');
    var rate = num(d.dataset.rate);
    var i = 0;
    function totals() {
      var l = num(labour.value) * rate, p = num(parts.value), sub = l + p;
      setText(d, '[data-l-amt]', bhd(l));
      setText(d, '[data-p-amt]', bhd(p));
      setText(d, '[data-sub]', bhd(sub));
      setText(d, '[data-vat]', bhd(sub * VAT));
      setText(d, '[data-total]', bhd(sub * (1 + VAT)));
    }
    function show() {
      steps.forEach(function (s, k) { s.hidden = k !== i; });
      dots.forEach(function (li, k) {
        li.classList.toggle('done', k < i);
        li.classList.toggle('on', k === i);
        if (k === i) li.setAttribute('aria-current', 'step'); else li.removeAttribute('aria-current');
      });
      next.hidden = i === steps.length - 1;
      next.textContent = steps[i].dataset.next || next.textContent;
      reset.hidden = i !== steps.length - 1;
      totals();
    }
    next.addEventListener('click', function () { if (i < steps.length - 1) { i++; show(); steps[i].focus(); } });
    reset.addEventListener('click', function () { i = 0; show(); steps[0].focus(); });
    labour.addEventListener('input', totals);
    parts.addEventListener('input', totals);
    show();
  });

  /* ---- Contact form ----
     data-endpoint: a form-service URL (e.g. Formspree) to receive requests directly.
     Without it, the form opens the visitor's email app addressed to data-email. */
  var form = document.getElementById('contact-form');
  if (form) {
    var done = document.getElementById('form-done');
    var status = document.getElementById('form-status');
    var msg = function (k) { return form.getAttribute('data-msg-' + k) || ''; };
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.reportValidity()) return;
      var endpoint = form.getAttribute('data-endpoint');
      var fd = new FormData(form);
      if (!endpoint) {
        var to = form.getAttribute('data-email');
        if (!to) { status.textContent = msg('none'); return; }
        var L = isAr
          ? ['الاسم', 'الشركة', 'البريد الإلكتروني', 'الهاتف', 'حجم الشركة', 'الاهتمامات']
          : ['Name', 'Company', 'Email', 'Phone', 'Company size', 'Interested in'];
        var body = L[0] + ': ' + (fd.get('name') || '') + '\n' + L[1] + ': ' + (fd.get('company') || '') +
          '\n' + L[2] + ': ' + (fd.get('email') || '') + '\n' + L[3] + ': ' + (fd.get('phone') || '') +
          '\n' + L[4] + ': ' + (fd.get('size') || '') + '\n' + L[5] + ': ' + fd.getAll('topics').join(', ') +
          '\n\n' + (fd.get('message') || '');
        var subj = (isAr ? 'طلب استشارة — ' : 'Consultation request — ') + (fd.get('company') || fd.get('name') || '');
        window.location.href = 'mailto:' + to + '?subject=' + encodeURIComponent(subj) + '&body=' + encodeURIComponent(body);
        status.textContent = msg('mailto');
        return;
      }
      var sb = form.querySelector('button[type="submit"]');
      var label = sb.textContent;
      sb.disabled = true; sb.textContent = msg('sending');
      fetch(endpoint, { method: 'POST', body: fd, headers: { Accept: 'application/json' } })
        .then(function (r) {
          if (!r.ok) throw new Error('bad');
          form.hidden = true; done.hidden = false; done.focus();
        })
        .catch(function () {
          status.textContent = msg('error');
          sb.disabled = false; sb.textContent = label;
        });
    });
  }

  /* ---- Footer year ---- */
  document.querySelectorAll('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });
})();
